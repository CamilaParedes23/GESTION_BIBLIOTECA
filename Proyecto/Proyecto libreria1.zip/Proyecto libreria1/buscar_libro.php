<?php
// buscar_libro.php

// Datos de conexión a la base de datos PostgreSQL
$host = "localhost"; // Reemplaza con tu host de PostgreSQL
$dbname = "Biblioteca"; // Reemplaza con tu nombre de base de datos
$user = "postgres"; // Reemplaza con tu usuario de PostgreSQL
$password = "121212"; // Reemplaza con tu contraseña de PostgreSQL

// Conexión a la base de datos
$dsn = "pgsql:host=$host;dbname=$dbname;user=$user;password=$password";
try {
  $pdo = new PDO($dsn);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Conexión a la base de datos exitosa.";
} catch (PDOException $e) {
  die("Error de conexión: " . $e->getMessage());
}

// Inicializa la variable $searchResult
$searchResult = [];

// Inicializa la variable $bookId
$bookId = '';

// Verifica si se ha enviado un formulario de búsqueda
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Obtiene el ID del libro ingresado por el usuario
  $bookId = filter_var($_POST["bookId"], FILTER_SANITIZE_NUMBER_INT);

  // Valida el ID del libro
  if (!$bookId || $bookId < 1) {
    echo "<p>Error: El ID del libro debe ser un número entero positivo.</p>";
    exit;
  }

  // Muestra el valor de $bookId para depuración
  echo "Valor de \$bookId: " . $bookId;

  // Realiza la búsqueda en la base de datos
  $stmt = $pdo->prepare("SELECT * FROM libros WHERE id_libros = :bookId");
  $stmt->bindParam(':bookId', $bookId);

  // Muestra la consulta SQL para depuración
  echo "Consulta SQL: " . $stmt->queryString;

  try {
    // Ejecuta la consulta
    $stmt->execute();

    // Obtiene los resultados de la búsqueda
    $searchResult = $stmt->fetch(PDO::FETCH_ASSOC);

    // Muestra información sobre errores
    if ($stmt->errorCode() !== '00000') {
      die("Error al obtener resultados: " . implode(", ", $stmt->errorInfo()));
    }

  } catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
  }
}

// Muestra los resultados en el HTML
if (!empty($searchResult)) {
  echo '<h3>Resultados de la búsqueda para el ID ' . $bookId . '</h3>';
  echo '<p>ID: ' . $searchResult['id_libros'] . '</p>';
  echo '<p>Título: ' . $searchResult['titulo'] . '</p>';
  // Agrega más campos según la estructura de tu tabla en la base de datos
} else {
  echo '<p>No se encontraron resultados para el ID ' . $bookId . '</p>';
}
?>
