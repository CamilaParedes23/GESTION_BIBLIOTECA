

function validarFormulario() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Verificar las credenciales para el bibliotecario
    if (username === 'bibliotecario' && password === 'bibliotecario1') {
        // Redireccionar al menú del bibliotecario después de iniciar sesión correctamente
        window.location.href = 'index2.html';
    }
    // Verificar las credenciales para el lector
    else if (username === 'lector' && password === 'lector1') {
        // Redireccionar al menú del lector después de iniciar sesión correctamente
        window.location.href = 'index.html';
    } else {
        alert('Credenciales incorrectas. Por favor, inténtalo de nuevo.');
    }

    // Evitar el envío del formulario predeterminado
    return false;
}
