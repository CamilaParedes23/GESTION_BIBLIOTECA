<?php
// buscar_libro.php
$host = "localhost"; // Reemplaza con tu host de PostgreSQL
$dbname = "Biblioteca"; // Reemplaza con tu nombre de base de datos
$user = "postgres"; // Reemplaza con tu usuario de PostgreSQL
$password = "121212"; // Reemplaza con tu contraseña de PostgreSQL

$conn = pg_connect("host=$host dbname=$dbname user=$user password=$password") or die('Error en la conexión: ' . pg_last_error());

$codigo = pg_escape_string($_REQUEST['codigo']);  // Evita SQL injection
$query = "SELECT * FROM libros WHERE id_libros = '$codigo'";
$consulta = pg_query($conn, $query) or die('Error en la consulta: ' . pg_last_error());

if (pg_num_rows($consulta) > 0) {
    while ($obj = pg_fetch_object($consulta)) {
        echo 'Datos del libro: ' . $obj->id_libros . '<br>';
        echo 'Nombre: ' . $obj->titulo_libr . '<br>';
        echo 'Genero: ' . $obj->genero_literario_libr . '<br>';
        echo 'Editorial: ' . $obj->editorial_libr . '<br>';
        echo 'Año Publicacion: ' . $obj->anio_publicacion_libr . '<br>';


    }
} else {
    echo 'Libro no encontrado';
}

// Cierra la conexión después de usarla
pg_close($conn);
?>
