// Obtener referencias a los elementos
var openModalBtn = document.getElementById('openModalBtn');
var closeModalBtn = document.getElementById('closeModalBtn');
var modal = document.getElementById('myModal');

// Abrir el modal al hacer clic en el botón
openModalBtn.onclick = function() {
  modal.style.display = 'block';
};

// Cerrar el modal al hacer clic en la "X" (close)
closeModalBtn.onclick = function() {
  modal.style.display = 'none';
};

// Cerrar el modal si el usuario hace clic fuera del contenido del modal
window.onclick = function(event) {
  if (event.target === modal) {
    modal.style.display = 'none';
  }
};
// Obtener referencias a los elementos
var draggableItems = document.querySelectorAll('.draggable-item');
var resetButton = document.getElementById('resetButton');

// Guardar la posición original de los elementos
var originalPositions = Array.from(draggableItems).map(function(item) {
  return { id: item.id, parent: item.parentElement };
});

// Agregar eventos de arrastrar y soltar a los elementos
draggableItems.forEach(function(item) {
  item.addEventListener('dragstart', handleDragStart);
  item.addEventListener('dragover', handleDragOver);
  item.addEventListener('dragenter', handleDragEnter);
  item.addEventListener('dragleave', handleDragLeave);
  item.addEventListener('drop', handleDrop);
  item.addEventListener('dragend', handleDragEnd);
});

// Agregar evento al botón de restablecer
resetButton.addEventListener('click', resetElements);

// Funciones de manejo de eventos
function handleDragStart(event) {
  event.dataTransfer.setData('text/plain', event.target.id);
}

function handleDragOver(event) {
  event.preventDefault();
}

function handleDragEnter(event) {
  event.target.classList.add('dragging');
}

function handleDragLeave(event) {
  event.target.classList.remove('dragging');
}

function handleDrop(event) {
  event.preventDefault();
  var draggedItemId = event.dataTransfer.getData('text/plain');
  var draggedItem = document.getElementById(draggedItemId);

  // Mover el elemento arrastrado al nuevo contenedor
  event.target.appendChild(draggedItem);

  // Limpiar clases de arrastre
  draggedItem.classList.remove('dragging');
}

function handleDragEnd(event) {
  // Limpiar clases de arrastre al finalizar el arrastre
  draggableItems.forEach(function(item) {
    item.classList.remove('dragging');
  });
}

// Función para restablecer los elementos a su posición original
function resetElements() {
  originalPositions.forEach(function(pos) {
    var item = document.getElementById(pos.id);
    pos.parent.appendChild(item);
  });
}

